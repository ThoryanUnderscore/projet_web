<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user']; // Contient les infos de l'utilisateur connecté

define("QUIZZES_FILE", "./gestionnaire/quizzes.txt");

// Chargement des quiz depuis le fichier texte
function loadQuizzes() {
    if (!file_exists(QUIZZES_FILE)) {
        return [];
    }

    $quizzes = [];
    $lines = file(QUIZZES_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    foreach ($lines as $line) {
        $parts = explode(";", $line);
        if (count($parts) >= 2) {
            $quizzes[] = ["title" => $parts[0], "status" => $parts[1]];
        }
    }

    return $quizzes;
}

$quizzes = loadQuizzes();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="public/css/dashboard.css">
    <link rel="stylesheet" href="public/css/navbar.css">
</head>
<body>
    <nav>
        <div class="nav-left">
            <a href="dashboard.php" class="logo">
                <img src="public/images/quizzeo_sansfond.png" alt="Logo">
            </a>
            <input type="text" placeholder="Recherchez un quiz" class="search">
        </div>
        
        <div class="nav-right">
            <a href="gestion_quiz.php" class="profile">Gestion Quiz</a>
            <a href="logout.php" class="logout">Déconnexion</a>
        </div>
    </nav>

    <div class="dashboard-container">
        <h1>Bienvenue, <?= htmlspecialchars($user['prenom']) . " " . htmlspecialchars($user['nom']); ?> !</h1>
        <p>Type de compte : <strong><?= htmlspecialchars($user['type']); ?></strong></p>

        <h2>Vos Quiz</h2>
        
        <?php if (!empty($quizzes)): ?>
            <table>
                <tr>
                    <th>Nom du Quiz</th>
                    <th>Statut</th>
                </tr>
                <?php foreach ($quizzes as $quiz): ?>
                    <tr>
                        <td><?= htmlspecialchars($quiz['title']) ?></td>
                        <td><?= htmlspecialchars($quiz['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>Aucun quiz trouvé.</p>
        <?php endif; ?>
    </div>
</body>
</html>
